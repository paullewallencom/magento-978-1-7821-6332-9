1. Merge all the files in your Magento root
2. Clear the Magento cache
3. The Packt_Helloworld module is installed in your Magento. The content in the files is the same as described in the recipes
4. This module is the result when you follow all the recipes in chapter 4. 