1. Merge this files into your Magento root
2. Clear your cache and the files will be loaded by Magento
3. The result you see, is what you have to become when you finish all the recipes of chapter 2. This are the code examples we will build in the recipes. 
