1. The files you see here is the result of the Magento when you follow all the recipes in chapter 6. 
2. To see this code in action, merge this folder in with the folders in the Magento root.
3. Whe you clear the cache, the module is installed and all the features described in the recipes should work. 