Paste the folder unit-tests in your Magento root to add the unit test files. 
Make sure you have installed the full Packt_Helloworld module. If not, you can use the zip file from chapter 8. 
