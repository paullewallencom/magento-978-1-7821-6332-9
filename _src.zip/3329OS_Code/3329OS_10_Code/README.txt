1. The files you see here is the result of the Magento when you follow all the recipes in chapter 10. 
2. To see this code in action, merge this folder in with the folders in the Magento root.
3. Make sure you have to add the carouFredSel library in the folder skin/frontend/base/default/js. For more information, we refer to the last recipe. 