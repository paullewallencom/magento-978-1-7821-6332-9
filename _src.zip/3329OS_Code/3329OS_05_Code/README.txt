1. Make sure you have installed the files of chapter 4. If not, do it. 
2. Paste the IndexController in the following folder of you Magento installation

app/code/local/Packt/Helloworld/controllers

3. You can now browse to the actions as described in the recipes referring to actions in the IndexController. The results has to be the same as in the recipes. 