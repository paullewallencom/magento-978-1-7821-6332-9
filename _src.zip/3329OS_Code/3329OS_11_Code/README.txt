In this folder you will find the .htaccess (example.htaccess) file that is used to optimize the performance. 
Copy this file to the root folder of your Magento installation and rename it to .htaccess. 
